SmartMouth� Flash Extension by Ajar Productions
README File

INSTALLATION

SmartMouth is installed using Adobe's free Extension Manager (available at http://www.adobe.com/exchange/em_download). Extension Manager (EM) is installed along with Flash Professional. 


Flash Pro CS3 - CS6
Inside this directory, you will find a file named SmartMouth.mxp. The simplest way to install SmartMouth is to double-click on this file. In most cases, this will automatically launch EM and begin the installation process. In some cases, double-clicking may not launch the correct version of EM. The EM version corresponds directly with the version of Flash. For instance, if you want to install SmartMouth into Flash CS5, make sure you are using EM CS5. You may need to launch EM separately and click the "Install" button. Read the license agreement and follow the instructions. After you've installed the extension, you may need to restart Flash.

Flash Pro CC
Inside this directory, you will find a file named SmartMouth_cc.zxp. The simplest way to install SmartMouth is to double-click on this file. In most cases, this will automatically launch EM and begin the installation process. In some cases, double-clicking may launch a different version of EM. The EM version corresponds directly with the version of Flash. You may need to launch EM CC separately and click the "Install" button. Read the license agreement and follow the instructions. After you've installed the extension, you may need to restart Flash.

SUPPORT
http://smartmouth.ajarproductions.com
support@ajarproductions.com